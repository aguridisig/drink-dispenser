package com.example.drinkdispenser.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Coin {
    EURO(100),
    TWO_EURO(200),
    FIFTY_CENTS(50),
    TWENTY_CENTS(20),
    TEN_CENTS( 10 ),
    FIVE_CENTS( 5 );

    private int value;
}
