package com.example.drinkdispenser.service;

import java.util.Map;
import com.example.drinkdispenser.entities.Item;
import com.example.drinkdispenser.entities.Stock;

import lombok.Getter;

@Getter
public class ItemService
{
    private Stock<Item> stockItem;

    public ItemService( Stock<Item> stockItem )
    {
        this.stockItem = stockItem;
    }

    public void sellItem( Item item )
    {
        stockItem.subtract( item );
    }

    public String displayStockItems()
    {
        Map<Item, Integer> stock = stockItem.getStock();
        StringBuilder stringBuilder = new StringBuilder( "-Available products\n" );
        for ( Item i : stock.keySet() )
        {

            stringBuilder.append( i.getName() + ": " + stock.get( i ) + " units\n" );
        }
        return stringBuilder.toString();
    }


}
