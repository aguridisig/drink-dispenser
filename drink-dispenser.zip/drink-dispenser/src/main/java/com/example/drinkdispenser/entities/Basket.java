package com.example.drinkdispenser.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Basket<K,V>
{
    private K first;
    private V second;
}
