package com.example.drinkdispenser.entities;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;

@Getter
public class Stock<T>
{
    private Map<T, Integer> stock = new HashMap<>();

    public boolean hasItem( T item )
    {
        return getQuantity( item ) > 0;
    }

    public int getQuantity( T item )
    {
        Integer value = stock.get( item );
        return value == null ? 0 : value;
    }

    public void add( T item )
    {
        int count = stock.get( item );
        stock.put( item, count + 1 );
    }

    public void subtract( T item )
    {
        if ( hasItem( item ) )
        {
            int count = stock.get( item );
            stock.put( item, count - 1 );
        }
    }

    public void clear()
    {
        stock.clear();
    }

    public void put( T item, int quantity )
    {
        stock.put( item, quantity );
    }
}
