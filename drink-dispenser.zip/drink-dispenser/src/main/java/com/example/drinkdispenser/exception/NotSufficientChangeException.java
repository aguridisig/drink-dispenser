package com.example.drinkdispenser.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NotSufficientChangeException extends RuntimeException
{
    private String message;
}
