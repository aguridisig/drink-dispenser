package com.example.drinkdispenser.controller;

import java.util.List;
import com.example.drinkdispenser.exception.NotFullPaidException;
import com.example.drinkdispenser.exception.NotSufficientChangeException;
import com.example.drinkdispenser.exception.SoldOutException;
import com.example.drinkdispenser.entities.Basket;
import com.example.drinkdispenser.entities.Coin;
import com.example.drinkdispenser.entities.Item;
import com.example.drinkdispenser.service.CoinService;
import com.example.drinkdispenser.service.ItemService;

public class DrinkDispenser
{
    private final CoinService coinService;

    private final ItemService itemService;
    private Item itemSelected;

    private int totalSales;

    public DrinkDispenser( final CoinService coinService, final ItemService itemService )
    {
        this.itemService = itemService;
        this.coinService = coinService;
    }

    public double insertCoin( final Coin coin )
    {

        coinService.insertCoin( coin );
        return ( double ) coinService.getInsertedCoins() / 100;
    }

    public int selectItemAndGetPrice( final int code )
    {
        itemSelected = null;
        if ( itemService.getStockItem().hasItem( Item.valueOf( code ) ) )
        {
            itemSelected = Item.valueOf( code );
            return itemSelected.getPrice();
        }
        throw new SoldOutException( "Sold Out, Please buy another item" );
    }

    public String cancelPurchase()
    {
        itemSelected = null;
        final List<Coin> coinListToReturn = coinService.cancelTransaccionAndReturnCoins();
        final StringBuilder coinsReturned = new StringBuilder("\nCoins returned: ");
        for ( Coin coin:coinListToReturn )
        {
            coinsReturned.append( (double) coin.getValue()/100+"Euro / " );
        }
        return "Transaction was cancelled\n"+ coinsReturned;
    }

    public Basket<Item, List<Coin>> collectItemAndChange()
    {
        final Item item = collectItem();
        totalSales = totalSales + itemSelected.getPrice();

        final List<Coin> change = coinService.collectChange( itemSelected );

        return new Basket<>( item, change );
    }

    private Item collectItem() throws NotSufficientChangeException,
            NotFullPaidException
    {
        if ( coinService.isFullPaid( itemSelected ) )
        {
            if ( coinService.hasSufficientChange( itemSelected ) )
            {
                itemService.sellItem( itemSelected );
                return itemSelected;
            }
            throw new NotSufficientChangeException( "Not Sufficient change, Please insert the exact amount" );

        }
        final double remainingBalance = itemSelected.getPrice() - coinService.getInsertedCoins();
        throw new NotFullPaidException( "Payment incomplete, remaining : " +
                remainingBalance );
    }

    public String displayReport()
    {
        StringBuilder report = new StringBuilder("---Daily Report---\n");
        report.append( "-Total sales: " + ( double ) totalSales / 100 + "Euros\n");
        report.append( itemService.displayStockItems() );
        return report.toString();
    }
}
