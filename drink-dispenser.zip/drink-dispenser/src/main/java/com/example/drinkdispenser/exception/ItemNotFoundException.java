package com.example.drinkdispenser.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ItemNotFoundException extends RuntimeException
{
    private String message;
}
