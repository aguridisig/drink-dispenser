package com.example.drinkdispenser.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.example.drinkdispenser.exception.NotSufficientChangeException;
import com.example.drinkdispenser.entities.Coin;
import com.example.drinkdispenser.entities.Item;
import com.example.drinkdispenser.entities.Stock;

import lombok.Getter;

@Getter
public class CoinService
{
    private int insertedCoins;
    private final Stock<Coin> stockCoins;

    public CoinService( final Stock<Coin> stockCoins )
    {
        this.stockCoins = stockCoins;
    }

    public void insertCoin( final Coin coin )
    {
        insertedCoins = ( insertedCoins + coin.getValue() );
        stockCoins.add( coin );
    }
    public List<Coin> cancelTransaccionAndReturnCoins(){
        final int amountToReturn = insertedCoins;
        insertedCoins=0;
        return this.collectChange( amountToReturn );
    }

    public List<Coin> collectChange( final Item itemSelected )
    {
        final double changeAmount = insertedCoins - itemSelected.getPrice();
        final List<Coin> change = getChange( changeAmount );
        updateCashInventory( change );
        insertedCoins = 0;
        return change;
    }
    public List<Coin> collectChange( final int amount )
    {
        final List<Coin> change = getChange( amount );
        updateCashInventory( change );
        insertedCoins = 0;
        return change;
    }
    public boolean isFullPaid( final Item itemSelected )
    {
        if ( insertedCoins >= itemSelected.getPrice() )
        {
            return true;
        }
        return false;
    }
    public boolean hasSufficientChange( final Item itemSelected )
    {
        return hasSufficientChangeForAmount( insertedCoins - itemSelected.getPrice() );
    }

    private boolean hasSufficientChangeForAmount( final double amount )
    {
        boolean hasChange = true;
        try
        {
            getChange( amount );
        }
        catch ( NotSufficientChangeException nsce )
        {
            return hasChange = false;
        }

        return hasChange;
    }

    private List<Coin> getChange( final double amount ) throws NotSufficientChangeException
    {
        List<Coin> changes = Collections.emptyList();

        if ( amount > 0 )
        {
            changes = new ArrayList<>();
            double balance = amount;
            while ( balance > 0 )
            {
                if ( balance >= Coin.TWO_EURO.getValue()
                        && stockCoins.hasItem( Coin.TWO_EURO ) )
                {
                    changes.add( Coin.TWO_EURO );
                    balance = balance - Coin.TWO_EURO.getValue();

                }
                else if ( balance >= Coin.EURO.getValue()
                        && stockCoins.hasItem( Coin.EURO ) )
                {
                    changes.add( Coin.EURO );
                    balance = balance - Coin.EURO.getValue();

                }
                else if ( balance >= Coin.FIFTY_CENTS.getValue()
                        && stockCoins.hasItem( Coin.FIFTY_CENTS ) )
                {
                    changes.add( Coin.FIFTY_CENTS );
                    balance = balance - Coin.FIFTY_CENTS.getValue();

                }
                else if ( balance >= Coin.TWENTY_CENTS.getValue()
                        && stockCoins.hasItem( Coin.TWENTY_CENTS ) )
                {
                    changes.add( Coin.TWENTY_CENTS );
                    balance = balance - Coin.TWENTY_CENTS.getValue();

                }
                else if ( balance >= Coin.FIVE_CENTS.getValue()
                        && stockCoins.hasItem( Coin.FIVE_CENTS ) )
                {
                    changes.add( Coin.FIVE_CENTS );
                    balance = balance - Coin.FIVE_CENTS.getValue();

                }
                else
                {
                    throw new NotSufficientChangeException( "NotSufficientChange, Please try another product" );
                }
            }
        }

        return changes;
    }

    private void updateCashInventory( final List<Coin> change )
    {
        for ( Coin c : change )
        {
            stockCoins.subtract( c );
        }
    }
}
