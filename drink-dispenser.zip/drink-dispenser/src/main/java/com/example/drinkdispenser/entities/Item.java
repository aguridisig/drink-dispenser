package com.example.drinkdispenser.entities;


import com.example.drinkdispenser.exception.ItemNotFoundException;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Item
{
    COCA(1,100,"Coke"),
    REDBULL(2,125,"Redbull"),
    WATER(3,50,"Water"),
    ORANGE_JUICE(4,195,"Orange Juice");

    private int code;
    private int price;
    private String name;

    public static Item valueOf(int itemCode){
        for(Item item: Item.values()){
            if(itemCode == item.getCode()){
                return item;
            }
        }
        throw  new ItemNotFoundException( "Item not Found" );
    }

}
