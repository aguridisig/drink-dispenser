package com.example.drinkdispenser;

import static org.junit.Assert.*;


import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.drinkdispenser.controller.DrinkDispenser;
import com.example.drinkdispenser.exception.ItemNotFoundException;
import com.example.drinkdispenser.exception.NotFullPaidException;
import com.example.drinkdispenser.exception.NotSufficientChangeException;
import com.example.drinkdispenser.exception.SoldOutException;
import com.example.drinkdispenser.entities.Basket;
import com.example.drinkdispenser.entities.Coin;
import com.example.drinkdispenser.entities.Item;
import com.example.drinkdispenser.entities.Stock;
import com.example.drinkdispenser.service.CoinService;
import com.example.drinkdispenser.service.ItemService;

public class DrinkDispenserTest
{

    private DrinkDispenser drinkDispenser;
    private final Stock<Coin> stockCoins = new Stock<>();
    private final Stock<Item> stockItems = new Stock<>();

    private final CoinService coinService = new CoinService( stockCoins );
    private final ItemService itemService = new ItemService( stockItems );


    @Before
    public void setUp()
    {
        for ( Coin c : Coin.values() )
        {
            stockCoins.put( c, 1 );
        }

        for ( Item i : Item.values() )
        {
            stockItems.put( i, 5 );
        }

        drinkDispenser = new DrinkDispenser( coinService, itemService );

    }

    @After
    public void tearDown()
    {
        drinkDispenser = null;
        stockItems.clear();
        stockCoins.clear();
    }

    @Test
    public void buyItemExactMoney()
    {
        final int price = drinkDispenser.selectItemAndGetPrice( 2 );
        assertEquals( 125, price );
        double credit = 0;
        credit = drinkDispenser.insertCoin( Coin.EURO );
        credit = drinkDispenser.insertCoin( Coin.TWENTY_CENTS );
        credit = drinkDispenser.insertCoin( Coin.FIVE_CENTS );
        System.out.println( "Credit: " + credit );

        final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();
        final Item item = basket.getFirst();
        int sum = 0;
        for ( Coin c : basket.getSecond() )
        {
            sum += c.getValue();
        }
        System.out.println( "Product: " + basket.getFirst().getName() + "\nChange: " + sum );
        assertEquals( 0, sum );
    }

    @Test
    public void buyItemAndCalculateChange()
    {
        final int price = drinkDispenser.selectItemAndGetPrice( 2 );
        assertEquals( 125, price );
        drinkDispenser.insertCoin( Coin.TWO_EURO );

        final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();
        final Item item = basket.getFirst();
        int sum = 0;
        final StringBuilder changeCoins = new StringBuilder( "\nDetail of change coins: " );
        for ( Coin c : basket.getSecond() )
        {
            sum += c.getValue();
            changeCoins.append( c.name() + " " );
        }
        System.out.println( "Product: " + basket.getFirst().getName() + "\nChange: " + sum + changeCoins );
        assertEquals( 75, sum );
    }

    @Test()
    public void buyAllCokesProductsAndReport()
    {
        int price = drinkDispenser.selectItemAndGetPrice( 1 );
        assertEquals( 100, price );

        for ( int i = 0; i < 5; i++ )
        {
            drinkDispenser.insertCoin( Coin.EURO );
            final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();
            final Item item = basket.getFirst();
        }

        System.out.println( drinkDispenser.displayReport() );
    }

    @Test
    public void CancelTransaction()
    {
        final int price = drinkDispenser.selectItemAndGetPrice( 2 );
        assertEquals( 125, price );
        double credit = 0;
        credit = drinkDispenser.insertCoin( Coin.EURO );
        credit = drinkDispenser.insertCoin( Coin.TWENTY_CENTS );
        credit = drinkDispenser.insertCoin( Coin.FIVE_CENTS );
        System.out.println( "Credit: " + credit );


        System.out.println( drinkDispenser.cancelPurchase() );


    }

    @Test( expected = NotSufficientChangeException.class )
    public void buyProductsAndNotEnoughChange()
    {
        //Buy 2 times the same product and no enough coins to give change
        for ( int i = 0; i < 2; i++ )
        {
            int price = drinkDispenser.selectItemAndGetPrice( 4 );
            assertEquals( 195, price );
            drinkDispenser.insertCoin( Coin.TWO_EURO );


            final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();
            final Item item = basket.getFirst();

        }
    }


    @Test( expected = NotFullPaidException.class )
    public void NotEnoughCredit()
    {

        final int price = drinkDispenser.selectItemAndGetPrice( 1 );
        assertEquals( 100, price );

        drinkDispenser.insertCoin( Coin.FIFTY_CENTS );

        final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();

    }

    @Test( expected = SoldOutException.class )
    public void NotItemAvailable()
    {
        //Remove items from stock
        for ( int i = 0; i < 5; i++ )
        {
            stockItems.subtract( Item.WATER );
        }
        System.out.println( drinkDispenser.displayReport() );

        final int price = drinkDispenser.selectItemAndGetPrice( 3 );
        assertEquals( 50, price );

        drinkDispenser.insertCoin( Coin.FIFTY_CENTS );

        final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();

    }

    @Test( expected = ItemNotFoundException.class )
    public void ItemNotFound()
    {

        final int price = drinkDispenser.selectItemAndGetPrice( 22 );
        assertEquals( 100, price );

        drinkDispenser.insertCoin( Coin.FIFTY_CENTS );

        final Basket<Item, List<Coin>> basket = drinkDispenser.collectItemAndChange();

    }

    @Test
    public void displayStock()
    {
        System.out.println( drinkDispenser.displayReport() );
    }
}